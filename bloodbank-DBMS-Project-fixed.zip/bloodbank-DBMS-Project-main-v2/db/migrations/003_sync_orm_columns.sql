-- ============================================================================
-- 003_sync_orm_columns.sql
-- ----------------------------------------------------------------------------
-- Migrations 001/002 create blood_bank and blood_unit without a few columns
-- that the SQLAlchemy models (app/models/*.py) read and write. Because
-- db_init() only runs create_all() on tables that DON'T exist yet, a database
-- built from the migrations never gets those columns, and the API fails at
-- startup with "Unknown column 'blood_bank.city'".
--
-- This migration adds the missing columns. It is idempotent: each column is
-- only added if information_schema says it is absent, so it is safe to re-run.
--
-- Apply after 001 and 002:
--   mysql -u root -p bloodbank < db/migrations/003_sync_orm_columns.sql
-- ============================================================================

DROP PROCEDURE IF EXISTS sync_orm_columns;

DELIMITER //
CREATE PROCEDURE sync_orm_columns()
BEGIN
    -- blood_bank.city
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'blood_bank'
          AND COLUMN_NAME = 'city'
    ) THEN
        ALTER TABLE blood_bank ADD COLUMN city VARCHAR(60) NOT NULL DEFAULT 'Pune';
    END IF;

    -- blood_bank.email
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'blood_bank'
          AND COLUMN_NAME = 'email'
    ) THEN
        ALTER TABLE blood_bank ADD COLUMN email VARCHAR(100) DEFAULT NULL;
    END IF;

    -- blood_bank.created_at
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'blood_bank'
          AND COLUMN_NAME = 'created_at'
    ) THEN
        ALTER TABLE blood_bank ADD COLUMN created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
    END IF;

    -- blood_unit.discard_reason
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'blood_unit'
          AND COLUMN_NAME = 'discard_reason'
    ) THEN
        ALTER TABLE blood_unit ADD COLUMN discard_reason TEXT DEFAULT NULL;
    END IF;

    -- blood_unit.created_at
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'blood_unit'
          AND COLUMN_NAME = 'created_at'
    ) THEN
        ALTER TABLE blood_unit ADD COLUMN created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
    END IF;
END //
DELIMITER ;

CALL sync_orm_columns();
DROP PROCEDURE IF EXISTS sync_orm_columns;
